vivado 2020.2
新建一个基于b220的vivado项目
系统设置增加IP目录
运行design_1.tcl
运用B220.xdc