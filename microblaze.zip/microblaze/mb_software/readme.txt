使用vivado 2020.2 输出的xsa
启动vitis 新建平台项目，选择standalone，去掉启动支持，编译平台
新建应用，选择上述新建standalone平台，使用空c项目模板
在src目录引入本目录的.h和main.c
编译elf
mb-objcopy -O binary main.elf main.bin
如为windows OS, 启动Xilinx Software Command Line Tool 2020.2，转向上述编译好的main.elf，执行上述命令
如为linux source <vitis 2020.2>/settings64.sh, 转向上述编译好的main.elf，执行上述命令